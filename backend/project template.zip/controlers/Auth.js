const bcrypt = require("bcrypt");
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer");
const config = require("config")
path = require('path');

const {userSchema} = require("../modules/User");

const User = mongoose.model("User", userSchema);


exports.userRegistration =async(req, res)=> {
    try {
        const {userEmail,userName,password} = req.body;
        const hashPassword = await bcrypt.hash(password,10); 

        const user = new User({
          userName:userName,
          userEmail:userEmail,
          password:hashPassword
        });
    
        const result = await user.save();
       
        const token = jwt.sign({userEmail:result.userEmail,_id:result._id},"private_key");
        if(token) return res.status(200).json({
          isLoged : true,
          token : token,
          error:null,
        });

        res.status(500).json({
          isLoged : false,
          token :"Create account but can't login",
          error: "Internal server error"
        });



      } catch (err) {
        res.status(500).send(err);
      }
    }

exports.userLogin = async(req, res)=> {
    try {
      const {userEmail,password} = req.body;

    const result = await User.findOne({ userEmail: userEmail })
   
        if (!result) {
          res.status(401).json({
            isLoged : false,
            token : null,
            error: "No account found. Create account using this email"
          });
          return;
        }
        const isEqual = await bcrypt.compare(password,result.password);

        if(isEqual){
        // const token = jwt.sign({userEmail:result.userEmail,_id:result._id},config.get("jwtPrivateKey"));
        const token = jwt.sign({userEmail:result.userEmail,_id:result._id},"private_key");
        if(token) return res.status(200).json({
          isLoged : true,
          token : token,
          error:null,
        });
        res.status(500).json({
          isLoged : false,
          token : null,
          error: "Internal server error"
        });
        } 

        res.status(401).json({
          isLoged : false,
          token : null,
          error: "Invalid password"
        });
     
    } catch (err) {
      res.status(500).json({
        isLoged : false,
        token : null,
        error: "Internal server error"
      });
      }
 }  
 
 
 exports.changePassword= async(req, res)=> {
 try{
  const {userEmail} = req.body;
  // const email = config.get("email");
  // const password = config.get("password");
  const email = "isurumadhumadhawa33072@gmail.com";
  const password = "ssckdrck";


  const result = await User.findOne({ userEmail: userEmail })
   
  if (!result) {
    res.status(401).json({
      isSend : false,
      error: "No account found. Create account using this email"
    });
    return;
  }


  var transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: email,
      pass: password
    }
  });

  var mailOptions = {
    from: email,
    to:userEmail ,
    subject: "Sending Email using Node.js",
    text: "use this link to change password - http://"+req.headers.host+"/api/auth/newPassword/"+result._id
  };

  transporter.sendMail(mailOptions, async (error, info) => {
    if (error) {
      res.status(500).json({
        isSend:false,
        error: "Internal server error"
      });
    console.log(error);
    } else {
      res.status(200).json({
        isSend:true,
        error: null
      });
    }
  })
 }catch(err){
  res.status(500).json({
    isSend:false,
    error: "Internal server error"
  });
 }
 }

 exports.newPassword= async(req, res)=> {
 try{
  if(!req.params.id) return res.status(500).send("something wrong !. Try again")

   res.render("index",{route:"/api/auth/restPassword/"+req.params.id})
  }catch(err){
    res.status(500).send("Internal server error")
  }
 }

 exports.restPassword= async(req, res)=> {
 
  try{
  if(!req.params.id) return res.status(500).send("something wrong !. Try again")

  const hashPassword = await bcrypt.hash(req.body.password,10);

  User.findByIdAndUpdate(
    { _id: req.params.id },
    { password: hashPassword },
    function(err, result) {
      if (err) {
        res.status(404).send("Not Found!");
      } else {
        res.status(200).send("changed password. Use new password to login");
      }
    }
  );
  }catch(err){
    res.status(500).send("Internal server error")
  }
 }